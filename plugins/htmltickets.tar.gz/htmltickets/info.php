<?php


function htmltickets_info() {
    return array
	('english_name' => 'HTML Tickets',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'tickets',
	 'summary' => 'Render tickets in HTML.',
	 'details' => 'This plugin renders tickets the user booked in html, so that the user may directly print from his browser, after booking tickets. Also works when tickets are displayed by the remail or adminprint plugins. ');
}

