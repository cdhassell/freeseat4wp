GRANT INSERT on $db.theatres TO $adminuser;
GRANT INSERT,DELETE on $db.seats TO $adminuser;
