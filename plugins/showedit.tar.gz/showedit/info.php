<?php

function showedit_info() {
    return array
	('english_name' => 'Show editor',
	 'version' => '1.0',
	 'required_fs_version' => '1.4.0',
	 'category' => 'configuration',
	 'summary' => 'Lets the admin create and modify shows.',
	 'details' => 'A show editor that lets creating and modifying show price, date and location information.');
}

